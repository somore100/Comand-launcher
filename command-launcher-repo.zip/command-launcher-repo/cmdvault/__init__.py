"""Command Vault application package."""
